/* Conditional compilation
* Created an external js file to define this debug variable, it is used to allow console log output
* during development and testing.
*/
var DEBUG = true;